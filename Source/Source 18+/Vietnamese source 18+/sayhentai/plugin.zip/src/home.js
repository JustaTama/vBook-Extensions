function execute() {
    return Response.success([
        { title: "Cập Nhật", input: "https://sayhentai.vip", script: "gen.js" },
        { title: "Manhwa", input: "https://sayhentai.vip/genre/manhwa", script: "gen.js" },
        { title: "Manga", input: "https://sayhentai.vip/genre/manga", script: "gen.js" },
        { title: "Manhua", input: "https://sayhentai.vip/genre/manhua", script: "gen.js" },
    ]);
}