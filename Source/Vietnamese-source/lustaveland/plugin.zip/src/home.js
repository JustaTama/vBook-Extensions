function execute() {
    return Response.success([
        {title: "Mới cập nhật (T.Tranh)", input: "https://luvevalands.com/danh-sach-chuong-moi-cap-nhat", script: "gen2.js"},
        {title: "Mới cập nhật (T.Chữ)", input: "https://luvevaland.co/danh-sach-chuong-moi-cap-nhat/novel", script: "gen.js"},
        {title: "Đã Hoàn Thành (T.Tranh)", input: "https://luvevalands.com/danh-sach-truyen-full/comic", script: "gen2.js"},
        {title: "Đã Hoàn Thành (T.Chữ)", input: "https://luvevaland.co/danh-sach-truyen-full/novel", script: "gen.js"},
    ]);
}
