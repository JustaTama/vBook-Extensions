function execute() {
    return Response.success([
        {title: "Truyện mới cập nhật", input: "https://hitruyen.vip", script: "jen.js"},
    ]);
}