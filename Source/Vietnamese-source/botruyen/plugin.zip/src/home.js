function execute() {
    return Response.success([
        {title: "Truyện Mới", input: "https://botruyen.vip/danh-sach/truyen-moi", script: "new.js"},
        {title: "Tiên Hiệp", input:  "https://botruyen.vip/i-category/tien-hiep", script: "gen.js"},
        {title: "Huyền Huyễn", input:  "https://botruyen.vip/i-category/huyen-ao", script: "gen.js"},
        {title: "Truyện Main Ác", input:  "https://botruyen.vip/i-category/truyen-main-ac", script: "gen.js"},
        {title: "Đô Thị", input:  "https://botruyen.vip/i-category/do-thi", script: "gen.js"},
        {title: "Võng Du", input:  "https://botruyen.vip/i-category/vong-du", script: "gen.js"},
        {title: "Harem", input:  "https://botruyen.vip/i-category/harem-truyen-nhieu-vo", script: "gen.js"},
        {title: "Dị Giới", input:  "https://botruyen.vip/i-category/di-gioi", script: "gen.js"},
        {title: "Xuyên Không", input:  "https://botruyen.vip/i-category/xuyen-khong", script: "gen.js"},
        {title: "Dị Năng", input:  "https://botruyen.vip/i-category/di-nang", script: "gen.js"},
        {title: "Truyện Voz", input:  "https://botruyen.vip/i-category/truyen-voz", script: "gen.js"},
        {title: "Truyện Teen", input:  "https://botruyen.vip/i-category/truyen-teen", script: "gen.js"},
        {title: "Trọng Sinh", input:  "https://botruyen.vip/i-category/truyen-trong-sinh", script: "gen.js"},
        {title: "Sắc Hiệp", input:  "https://botruyen.vip/i-category/sac-hiep", script: "gen.js"},
        {title: "Hệ Thống", input:  "https://botruyen.vip/i-category/truyen-he-thong", script: "gen.js"},
        {title: "Mạt Thế", input:  "https://botruyen.vip/i-category/truyen-mat-the", script: "gen.js"},
        {title: "Ngôn Tình", input:  "https://botruyen.vip/i-category/ngon-tinh", script: "gen.js"},
        {title: "Nữ Cường", input:  "https://botruyen.vip/i-category/truyen-nu-cuong", script: "gen.js"},
        {title: "Điền Văn", input:  "https://botruyen.vip/i-category/dien-van", script: "gen.js"},
    ]);
}