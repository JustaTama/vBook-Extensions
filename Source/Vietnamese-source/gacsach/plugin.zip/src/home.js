function execute() {
    return Response.success([
        {
            title: "Truyện Mới Cập Nhật",
            script: "news.js",
            input: "https://gacsach.club"
        }
    ])
}

