function execute() {
    return Response.success([
        {title: "Mới Cập Nhật", input: "https://hotruyen.com/", script: "gen.js"}
    ]);
}