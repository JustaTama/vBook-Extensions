function execute() {
    return Response.success([
        {title: "Mới Cập Nhật", input: "https://manhuarock.net/", script: "gen.js"},
        {title: "Xem nhiều", input: "https://manhuarock.net/xem-nhieu", script: "gen.js"},
        {title: "Xuyên Không", input: "https://manhuarock.net/the-loai/xuyen-khong", script: "gen.js"},
        {title: "Trọng Sinh", input: "https://manhuarock.net/the-loai/trong-sinh", script: "gen.js"},
        {title: "Chuyển Sinh", input: "https://manhuarock.net/the-loai/chuyen-sinh", script: "gen.js"},
        {title: "Ngôn Tình", input: "https://manhuarock.net/the-loai/ngon-tinh", script: "gen.js"},
        {title: "Lãng Mạn", input: "https://manhuarock.net/the-loai/lang-man", script: "gen.js"},
        {title: "Tổng Tài", input: "https://manhuarock.net/the-loai/tong-tai", script: "gen.js"},
        {title: "Tu Tiên", input: "https://manhuarock.net/the-loai/tu-tien", script: "gen.js"},
        {title: "Đô Thị", input: "https://manhuarock.net/the-loai/do-thi", script: "gen.js"},
        {title: "18+", input: "https://manhuarock.net/the-loai/adult", script: "gen.js"},
        {title: "Đã Hoàn thành", input: "https://manhuarock.net/hoan-thanh", script: "gen.js"},
    ]);
}