function execute() {
    return Response.success([
        {title: "Mới Cập Nhật", script: "top.js", input: "https://truyenyy.vip/truyen-moi-cap-nhat/"},
        {title: "Tiểu Thuyết Chọn Lọc", script: "top.js", input: "https://truyenyy.vip/tieu-thuyet-chon-loc/"},
        {title: "Truyện Mới Đăng", script: "top.js", input: "https://truyenyy.vip/truyen-moi-dang/"},
        {title: "Truyện Đề Xuất", script: "top.js", input: "https://truyenyy.vip/truyen-de-xuat/"},
        {title: "Kim Thánh Bảng TOP Truyện Chữ", script: "top.js", input: "https://truyenyy.vip/kim-thanh-bang/"},
        {title: "Đọc Nhiều Trong Tuần", script: "top.js", input: "https://truyenyy.vip/kim-thanh-bang/top/doc-nhieu-trong-tuan/"},
        {title: "Truyện VIP HOT", script: "top.js", input: "https://truyenyy.vip/kim-thanh-bang/top/truyen-vip-doc-nhieu/"},
        {title: "Truyện Ra Chương Nhanh", script: "top.js", input: "https://truyenyy.vip/kim-thanh-bang/top/truyen-ra-chuong-nhanh/"},
        {title: "Kim Thánh Bảng TOP Truyện Mới Đăng", script: "top.js", input: "https://truyenyy.vip/kim-thanh-bang/top/truyen-moi-dang/"},
        {title: "TOP Truyện Full", script: "top.js", input: "https://truyenyy.vip/kim-thanh-bang/top/truyen-full/"},
        {title: "TOP Truyện Đề Cử", script: "top.js", input: "https://truyenyy.vip/kim-thanh-bang/top/truyen-de-cu/"},
        {title: "TOP Theo Dõi", script: "top.js", input: "https://truyenyy.vip/kim-thanh-bang/top/truyen-theo-doi/"},
        {title: "TOP Bình Luận Sôi Nổi", script: "top.js", input: "https://truyenyy.vip/kim-thanh-bang/top/truyen-binh-luan-soi-noi/"},
        {title: "Truyện Nhiều Fan", script: "top.js", input: "https://truyenyy.vip/kim-thanh-bang/top/truyen-nhieu-fan/"}
    ]);
}


