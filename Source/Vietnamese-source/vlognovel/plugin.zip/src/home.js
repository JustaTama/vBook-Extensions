function execute() {
    return Response.success([
        {title: "Hot", input: "https://vlognovel.com/the-loai/dang-hot", script: "gen.js"},
        {title: "Mới Nhất", input: "https://vlognovel.com/the-loai/moi-cap-nhap", script: "gen.js"},
        {title: "Xem nhiều", input: "https://vlognovel.com/de-nghi/pho-bien/xem-nhieu", script: "gen.js"}
    ]);   
}