function execute() {
    return Response.success([
        {title: "Mới Cập Nhật", input: "https://www.medoctruyenchu.net/de-xuat/cap-nhat-moi/2", script: "news.js"},
        {title: "Truyện HOT", input: "https://www.medoctruyenchu.net/de-xuat/cap-nhat-hot/11", script: "news.js"},
        {title: "Đề Cử", input: "https://www.medoctruyenchu.net/de-xuat/truyen-full-de-cu/12", script: "news.js"},
        {title: "Tiên hiệp", input: "https://www.medoctruyenchu.net/de-xuat/tien-hiep/15", script: "news.js"},
        {title: "Ngôn tình", input: "https://www.medoctruyenchu.net/de-xuat/ngon-tinh/16", script: "news.js"},
        {title: "Xuyên không", input: "https://www.medoctruyenchu.net/de-xuat/xuyen-khong/17", script: "news.js"},
        {title: "Truyện Full Đề Cử", input: "https://www.medoctruyenchu.net/de-xuat/truyen-full-de-cu/12", script: "news.js"},
        {title: "Truyện Teen", input: "https://www.medoctruyenchu.net/de-xuat/truyen-teen/18", script: "news.js"},
        {title: "Đã Hoàn Thành", input: "https://www.medoctruyenchu.net/de-xuat/truyen-vua-ket-thuc/21", script: "news.js"},
    ]);
}
