function execute() {
    return Response.success([
        {title: "Mới Cập Nhật", input: "https://vlogtruyen2.net/the-loai/moi-cap-nhap", script: "gen.js"},
        {title: "Truyện HOT", input: "https://vlogtruyen2.net/the-loai/dang-hot", script: "gen.js"},
        {title: "Hệ Thống", input: "https://vlogtruyen2.net/the-loai/he-thong", script: "gen.js"},
        {title: "Huyền Huyễn", input: "https://vlogtruyen2.net/the-loai/huyen-huyen", script: "gen.js"},
        {title: "Chuyển Sinh", input: "https://vlogtruyen2.net/the-loai/chuyen-sinh", script: "gen.js"},
        {title: "Xuyên Không", input: "https://vlogtruyen2.net/the-loai/xuyen-khong", script: "gen.js"},
        {title: "Ngôn Tình", input: "https://vlogtruyen2.net/the-loai/ngon-tinh", script: "gen.js"},
        {title: "18+", input: "https://vlogtruyen2.net/the-loai/adult", script: "gen.js"},
        {title: "Đã Hoàn Thành", input: "https://vlogtruyen2.net/the-loai/moi-cap-nhap?status=1", script: "gen.js"},
    ]);
}