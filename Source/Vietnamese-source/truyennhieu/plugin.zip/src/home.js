function execute() {
    return Response.success([
        {title: "Mới Cập Nhật", input: "https://truyennhieu.com/the-loai/", script: "gen.js"},
        {title: "Huyền Huyễn", input: "https://truyennhieu.com/the-loai/huyen-huyen/5bdecab406c7c41b7eea20b9", script: "gen.js"},
        {title: "Xuyên Không", input: "https://truyennhieu.com/the-loai/xuyen-khong/5bdecab406c7c41b7eea20b8", script: "gen.js"},
        {title: "Trọng Sinh", input: "https://truyennhieu.com/the-loai/trong-sinh/5bdfb00f8ee5f91f329931cc", script: "gen.js"},
        {title: "Ngôn Tình", input: "https://truyennhieu.com/the-loai/ngon-tinh/5bdec27dc551731a60abe1ff", script: "gen.js"},
        {title: "Mạt Thế", input: "https://truyennhieu.com/the-loai/mat-the/5be267aa7f0e2b2fdfe64523", script: "gen.js"},
    ]);
}