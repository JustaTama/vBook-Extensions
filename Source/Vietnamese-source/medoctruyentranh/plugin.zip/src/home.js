function execute() {
    return Response.success([
        {title: "Truyện Được Đề Cử", input: "https://www.medoctruyentranh.net/de-xuat/de-xuat-truyen-moi/37", script: "news.js"},
        {title: "Mê Đọc Truyện", input: "https://www.medoctruyentranh.net/de-xuat/me-doc-truyen/19", script: "news.js"},
        {title: "Truyện Mới", input: "https://www.medoctruyentranh.net/de-xuat/tac-pham-moi/20", script: "news.js"},
        {title: "Truyện Nhiều Chương", input: "https://www.medoctruyentranh.net/de-xuat/truyen-nhieu-chuong/35", script: "news.js"},
        {title: "Tiên Hiệp", input: "https://www.medoctruyentranh.net/de-xuat/tien-hiep/28", script: "news.js"},
        {title: "Lãng mạn", input: "https://www.medoctruyentranh.net/de-xuat/lang-man/13", script: "news.js"},
        {title: "Tổng Tài", input: "https://www.medoctruyentranh.net/de-xuat/ba-dao-tong-tai/27", script: "news.js"},
        {title: "Con trai thích", input: "https://www.medoctruyentranh.net/de-xuat/con-trai-thich/12", script: "news.js"},
        {title: "Con gái thích", input: "https://www.medoctruyentranh.net/de-xuat/con-gai-thich/11", script: "news.js"},
        {title: "Thanh xuân vườn trường", input: "https://www.medoctruyentranh.net/de-xuat/thanh-xuan-vuon-truong/26", script: "news.js"},
        {title: "Chuyên mục Artbook", input: "https://www.medoctruyentranh.net/de-xuat/chuyen-muc-artbook/36", script: "news.js"},
    ]);
}
