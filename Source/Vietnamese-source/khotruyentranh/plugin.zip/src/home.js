function execute() {
    return Response.success([
        {title: "Mới Cập nhật", input: "https://khotruyentranhhot.com/danh-sach-truyen/", script: "gen.js"},
        {title: "Huyền Huyễn", input: "https://khotruyentranhhot.com/the-loai/huyen-huyen", script: "cat.js"},
        {title: "Trọng Sinh", input: "https://khotruyentranhhot.com/the-loai/trong-sinh", script: "cat.js"},
        {title: "Xuyên Không", input: "https://khotruyentranhhot.com/the-loai/xuyen-khong", script: "cat.js"},
        {title: "Đô Thị", input: "https://khotruyentranhhot.com/the-loai/do-thi", script: "cat.js"},
        {title: "Fantasy", input: "https://khotruyentranhhot.com/the-loai/fantasy", script: "cat.js"},
        {title: "Ngôn tình", input: "https://khotruyentranhhot.com/the-loai/ngon-tinh", script: "cat.js"},
        {title: "18+", input: "https://khotruyentranhhot.com/the-loai/truyen-tranh-18", script: "cat.js"},
    ]);
}