function execute() {
    return Response.success([
        { title: "Lastest", input: "https://hentaidexy.com", script: "gen.js" },
    ]);
}