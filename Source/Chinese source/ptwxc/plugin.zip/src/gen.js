function execute(url, page) {
    if (!page) page = '1';
    const doc = Http.get('https://www.ptwxc.com/category.html').params({
        order : url,
        page : page
    }).html();
    var next = doc.select('.pageLists').select('a.current + a').first().text();
    var allItem = doc.select('ul.list_details li')
    var list = [];
    allItem.forEach(item => {
        list.push({
            name: item.select('h3 a').text(),
            link: item.select('h3  a').attr('href'),
            cover: item.select('.hover-img img').attr('src'),
            description: item.select('.author').first().text().replace('作者：','') || 'Unknow',
            host: "https://www.ptwxc.com"
        })
    });
    return Response.success(list,next)
}