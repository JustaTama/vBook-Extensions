function execute() {
    return Response.success([
        {title: "东方玄幻", input: "99", script: "gen.js"},
        {title: "现代都市", input: "103", script: "gen.js"},
        {title: "脑洞创意", input: "135", script: "gen.js"},
        {title: "历史架空", input: "108", script: "gen.js"},
        {title: "军事战争", input: "113", script: "gen.js"},
        {title: "游戏竞技", input: "112", script: "gen.js"},
        {title: "武侠仙侠", input: "109", script: "gen.js"},
        {title: "科幻末世", input: "111", script: "gen.js"},
        {title: "灵异悬疑", input: "128", script: "gen.js"},
        {title: "西方奇幻", input: "107", script: "gen.js"},
    ]);
}